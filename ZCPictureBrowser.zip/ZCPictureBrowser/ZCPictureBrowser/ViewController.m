//
//  ViewController.m
//  ZCPictureBrowser
//
//  Created by Yu, Tian on 2020/8/27.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import "ViewController.h"
#import "ZCPictureBrowserManager.h"
#import <SDWebImage.h>

@interface ViewController () <UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSArray *imageArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = UIColor.whiteColor;
    
    NSArray *imageList = @[@"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200827095946860_9039.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101049593_8028.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101057778_6506.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101107916_8152.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/event/557088259/Screenshot_20200826_170045_com.jiayu.online.jpg",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200827095946860_9039.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101049593_8028.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101057778_6506.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101107916_8152.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/event/557088259/Screenshot_20200826_170045_com.jiayu.online.jpg",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200827095946860_9039.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101049593_8028.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101057778_6506.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101107916_8152.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/event/557088259/Screenshot_20200826_170045_com.jiayu.online.jpg",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200827095946860_9039.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101049593_8028.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101057778_6506.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/activity/20200817101107916_8152.png",
    @"https://jiayu-taotutu.oss-cn-beijing.aliyuncs.com/event/557088259/Screenshot_20200826_170045_com.jiayu.online.jpg"];
    
    self.imageArray = imageList;
    [self.view addSubview:self.collectionView];
    
}


#pragma mark - 代理
#pragma mark — UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.imageArray.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"TTClubPostCollectionCell" forIndexPath:indexPath];
    UIImageView *coverImageView = (UIImageView *)[cell.contentView viewWithTag:100];
    if (!coverImageView) {
        coverImageView = [[UIImageView alloc]initWithFrame:cell.contentView.bounds];
        coverImageView.contentMode = UIViewContentModeScaleAspectFill;
        coverImageView.tag = 100;
        coverImageView.clipsToBounds = YES;
        [cell.contentView addSubview:coverImageView];
    }
    
    [coverImageView sd_setImageWithURL:[NSURL URLWithString:self.imageArray[indexPath.row]]];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    //看大图
    [ZCPictureBrowserManager pictureBrowserWithImageArray:self.imageArray selectedIndex:indexPath.row fromView:collectionView complete:nil];
}

#pragma mark - 懒加载
- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
        flowLayout.minimumInteritemSpacing = 10;
        flowLayout.minimumLineSpacing = 10;
        flowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
        flowLayout.itemSize = CGSizeMake(([UIScreen mainScreen].bounds.size.width-30)/2.0, 180);
        
        _collectionView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.backgroundColor = UIColor.whiteColor;
        [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"TTClubPostCollectionCell"];
    }
    return _collectionView;
}

@end
