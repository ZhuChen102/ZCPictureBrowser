//
//  AppDelegate.h
//  ZCPictureBrowser
//
//  Created by Yu, Tian on 2020/8/27.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

