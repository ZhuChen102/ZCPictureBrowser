//
//  SceneDelegate.h
//  ZCPictureBrowser
//
//  Created by Yu, Tian on 2020/8/27.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

