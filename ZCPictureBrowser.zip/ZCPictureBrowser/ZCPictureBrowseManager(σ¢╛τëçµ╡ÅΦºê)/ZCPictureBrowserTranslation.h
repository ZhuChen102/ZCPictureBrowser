//
//  ZCPictureBrowserTranslation.h
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/13.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, TransitionType) {
    TransitionTypePresent = 0,//present动画
    TransitionTypeDissmiss
};

@interface ZCPictureBrowserTranslation : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic, assign) TransitionType transitionType;

@property (nonatomic, strong) UIView *fromView;
@property (nonatomic, assign) NSInteger beginIndex;

@property (nonatomic, strong) UIImageView *toImageView;
@property (nonatomic, assign) CGFloat toImageViewAlpha;
@property (nonatomic, assign) NSInteger finalIndex;
@end

NS_ASSUME_NONNULL_END
