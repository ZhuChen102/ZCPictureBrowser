//
//  ZCPictureBrowserManager.h
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^CompleteBlock)(NSInteger index);

@interface ZCPictureBrowserManager : NSObject

/// 跳转至图片浏览器
/// @param imageArray 网络图片字符串链接 （需要UIImage的话自己加）
/// @param selectedIndex 初始的位置
/// @param fromView 动画需要的视图，建议UICollectionView
/// @param complete 返回回调
+ (void)pictureBrowserWithImageArray:(NSArray <NSString *>*)imageArray
                       selectedIndex:(NSInteger)selectedIndex
                            fromView:(nullable UIView *)fromView
                            complete:(nullable CompleteBlock)complete;

@end

NS_ASSUME_NONNULL_END
