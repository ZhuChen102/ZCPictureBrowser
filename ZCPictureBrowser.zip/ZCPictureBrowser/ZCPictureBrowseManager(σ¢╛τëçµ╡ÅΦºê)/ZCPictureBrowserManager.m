//
//  ZCPictureBrowserManager.m
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import "ZCPictureBrowserManager.h"
#import "ZCPictureBrowserController.h"

@implementation ZCPictureBrowserManager

+ (void)pictureBrowserWithImageArray:(NSArray <NSString *>*)imageArray
                       selectedIndex:(NSInteger)selectedIndex
                            fromView:(nullable UIView *)fromView
                            complete:(nullable CompleteBlock)complete
{
    ZCPictureBrowserController *vc = [[ZCPictureBrowserController alloc] init];
    
    vc.imageArray = imageArray;
    vc.selectedIndex = selectedIndex;
    if (fromView) {
        vc.fromView = fromView;
    }
    if (complete) {
        vc.completeBlock = ^(NSInteger index) {
            complete(index);
        };
    }
    [[self topViewController] presentViewController:vc animated:YES completion:nil];
}

+ (UIViewController *)topViewController
{
    UIViewController *resultVC;
    resultVC = [ZCPictureBrowserManager _topViewController:[[self getKeyWindow] rootViewController]];
    while (resultVC.presentedViewController) {
        resultVC = [ZCPictureBrowserManager _topViewController:resultVC.presentedViewController];
    }
    return resultVC;
}
+ (UIWindow *)getKeyWindow
{
    UIWindow* window = nil;
    if (@available(iOS 13.0, *)) {
        for (UIWindowScene* windowScene in [UIApplication sharedApplication].connectedScenes) {
            if (windowScene.activationState == UISceneActivationStateForegroundActive) {
                window = windowScene.windows.firstObject;
                break;
            }
        }
    } else {
        window = [UIApplication sharedApplication].keyWindow;
    }
    return window;
}
+ (UIViewController *)_topViewController:(UIViewController *)vc
{
    if ([vc isKindOfClass:[UINavigationController class]]) {
        return [self _topViewController:[(UINavigationController *)vc topViewController]];
    } else if ([vc isKindOfClass:[UITabBarController class]]) {
        return [self _topViewController:[(UITabBarController *)vc selectedViewController]];
    } else {
        return vc;
    }
    return nil;
}
@end
