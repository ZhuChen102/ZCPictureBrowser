//
//  ZCPictureBrowserCell.m
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import "ZCPictureBrowserCell.h"
#import <SDWebImage.h>

#define MAX_MOVE_Y 150.0
#define SCREEN_W ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_H ([UIScreen mainScreen].bounds.size.height)

@interface ZCPictureBrowserCell () <UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *pictureScrollView;
@property (nonatomic, strong) UIImageView *pictureImageView;
@property (nonatomic, strong) UIImageView *animationImageView;
//
@property (nonatomic, assign) BOOL isZoom;
@property (nonatomic, assign) BOOL isDismiss;
@property (nonatomic, assign) CGFloat panBeginY;
@property (nonatomic, assign) CGFloat panBeginX;
@property (nonatomic, assign) CGRect beforeDragFrame;

@end

@implementation ZCPictureBrowserCell
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self initData];
        [self initUI];
        [self addGestureRecognizer];
    }
    return self;
}
- (void)initData {
    self.isZoom = NO;
    self.isDismiss = NO;
    self.panBeginX = 0;
    self.panBeginY = 0;
}
#pragma mark - UI
- (void)initUI {
    self.contentView.backgroundColor = UIColor.clearColor;
    
    [self.contentView addSubview:self.pictureScrollView];
    self.pictureScrollView.frame =self.contentView.bounds;

    [self.pictureScrollView addSubview:self.self.pictureImageView];
    self.pictureImageView.frame =  self.pictureScrollView.bounds;
}
- (void)addGestureRecognizer {
    //双击放大or缩小
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapAction:)];
    doubleTap.numberOfTapsRequired = 2;
    [self.pictureScrollView addGestureRecognizer:doubleTap];
    //返回
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapAction)];
    singleTap.numberOfTapsRequired = 1;
    singleTap.numberOfTouchesRequired = 1;
    //系统会先判定是不是双击，如果不是，才会调单击的事件
    [singleTap requireGestureRecognizerToFail:doubleTap];
    [self.pictureScrollView addGestureRecognizer:singleTap];
}

#pragma mark - 方法
#pragma mark -- 滑动后重置缩放大小
- (void)resetScale {
    self.pictureScrollView.zoomScale = 1.0;
}

#pragma mark -- 双击变大 or 变小
- (void)doubleTapAction:(UITapGestureRecognizer *)doubleTap {
    if(self.pictureScrollView.zoomScale <= 1){
        CGFloat x = [doubleTap locationInView:self.pictureScrollView].x + self.pictureScrollView.contentOffset.x;
        
        CGFloat y = [doubleTap locationInView:self.pictureScrollView].y + self.pictureScrollView.contentOffset.y;
        [self.pictureScrollView zoomToRect:(CGRect){{x,y},{0,0}} animated:true];
    }else{
        [self.pictureScrollView setZoomScale:1.f animated:true];
    }
}
- (void)singleTapAction {
    if (self.delegate && [self.delegate respondsToSelector:@selector(isNeedBack:)]) {
        UIImageView *imageView = [UIImageView new];
        CGRect frame = self.pictureImageView.frame;
        if (self.pictureImageView.bounds.size.height>= SCREEN_H) {
            frame.origin.y = -self.pictureScrollView.contentOffset.y;
        }
        if (self.pictureImageView.bounds.size.width >= SCREEN_W) {
            frame.origin.x = -self.pictureScrollView.contentOffset.x;
        }
        imageView.frame = frame;
        imageView.image = self.pictureImageView.image;
        imageView.contentMode = UIViewContentModeScaleAspectFill;

        [self.delegate isNeedBack:imageView];
    }
}
#pragma mark - 代理
#pragma mark -- 缩放
- (void)scrollViewWillBeginZooming:(UIScrollView *)scrollView withView:(UIView *)view {
    self.isZoom = YES;
}
- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    self.pictureImageView.center = [self centerOfScrollViewContent:scrollView];
    self.isZoom = NO;
}
- (CGPoint)centerOfScrollViewContent:(UIScrollView *)scrollView
{
    CGFloat offsetX = (scrollView.bounds.size.width > scrollView.contentSize.width) ? (scrollView.bounds.size.width - scrollView.contentSize.width) * 0.5 : 0.0;//x偏移
    CGFloat offsetY = (scrollView.bounds.size.height > scrollView.contentSize.height) ? (scrollView.bounds.size.height - scrollView.contentSize.height) * 0.5 : 0.0;//y偏移
    CGPoint actualCenter = CGPointMake(scrollView.contentSize.width * 0.5 + offsetX,scrollView.contentSize.height * 0.5 + offsetY);
    
    return actualCenter;
}
- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    return self.pictureImageView;
}

- (void)panGestureRecognizerAction:(UIPanGestureRecognizer *)pan {
    switch (pan.state) {
        case UIGestureRecognizerStateBegan: {
            if (self.pictureScrollView.contentOffset.y<0 && !self.isZoom && pan.numberOfTouches == 1) {
                self.isDismiss = YES;
                self.beforeDragFrame = (CGRect){{-self.pictureScrollView.bounds.origin.x,self.pictureImageView.frame.origin.y},self.pictureImageView.frame.size};
                self.panBeginY = [pan locationInView:self.contentView].y;//赋值初始Y
                self.panBeginX = [pan locationInView:self.contentView].x;//赋值初始Y
            }
        }break;
        case UIGestureRecognizerStateChanged: {
            if (self.isDismiss) {
                self.pictureImageView.hidden = YES;
                if (self.animationImageView == nil) {
                    self.animationImageView = [UIImageView new];
                    [self.contentView addSubview:self.animationImageView];
                    self.animationImageView.contentMode = UIViewContentModeScaleAspectFit;
                    self.animationImageView.frame = self.beforeDragFrame;
                    self.animationImageView.image = self.pictureImageView.image;
                }
                
                //计算随着手势移动后的frame
                CGFloat panCurrentX = [pan locationInView:self.contentView].x;//触摸点当前的x
                CGFloat panCurrentY = [pan locationInView:self.contentView].y;//触摸点当前的y
                
                CGFloat moveX = panCurrentX-self.panBeginX;
                CGFloat moveY = panCurrentY-self.panBeginY;
                                
                CGFloat scale = moveY/400.0;
                scale = scale>1.0?1.0:scale;
                
                CGFloat newWidth = 0;
                CGFloat newHeight = 0;
                CGFloat newY = self.beforeDragFrame.origin.y+moveY;
                CGFloat centerX = moveX+(self.beforeDragFrame.origin.x+self.beforeDragFrame.size.width/2.0);
                
                if (panCurrentY > self.panBeginY){
                    newWidth = self.beforeDragFrame.size.width - (self.beforeDragFrame.size.width - self.beforeDragFrame.size.width * 0.5) * scale;
                    newHeight = self.beforeDragFrame.size.height - (self.beforeDragFrame.size.height - self.beforeDragFrame.size.height * 0.5) * scale;
                } else {
                    newWidth = self.beforeDragFrame.size.width;
                    newHeight = self.beforeDragFrame.size.height;
                }
                self.animationImageView.frame = CGRectMake(0, newY, newWidth, newHeight);
                CGPoint center = self.animationImageView.center;
                center.x = centerX;
                self.animationImageView.center = center;
                
                if (self.delegate && [self.delegate respondsToSelector:@selector(refreshAlpha:)]) {
                    [self.delegate refreshAlpha: 1-scale];
                }
            }
        }break;
        case UIGestureRecognizerStateEnded: {
            if (self.isDismiss) {
                CGFloat panCurrentY = [pan locationInView:self.contentView].y;//触摸点当前的y                
                if (panCurrentY-self.panBeginY >= MAX_MOVE_Y) {
                    if (self.delegate && [self.delegate respondsToSelector:@selector(isNeedBack:)]) {
                        [self.delegate isNeedBack:self.animationImageView];
                    }
                }else {
                    //复原动画
                    [UIView animateWithDuration:0.3 animations:^{
                        self.animationImageView.frame = self.beforeDragFrame;
                    }completion:^(BOOL finished) {
                        if (self.delegate && [self.delegate respondsToSelector:@selector(refreshAlpha:)]) {
                            [self.delegate refreshAlpha: 1];
                        }
                        [self.pictureScrollView setContentOffset:CGPointMake(self.pictureScrollView.bounds.origin.x, 0) animated:NO];
                        self.animationImageView.hidden = YES;
                        self.pictureImageView.hidden = NO;
                        self.animationImageView = nil;
                    }];
                }
                
                self.panBeginY = 0;
                self.isDismiss = NO;
            }
            
//            NSLog(@"结束");
        }break;
        case UIGestureRecognizerStateCancelled: {
//            NSLog(@"取消");
        }break;
        case UIGestureRecognizerStateFailed: {
//            NSLog(@"失败");
        }break;
        case UIGestureRecognizerStatePossible: { //默认状态，尚未识别其手势
//            NSLog(@"默认状态");
        }break;
    }
}

#pragma mark - SETTING
- (void)setIsDismiss:(BOOL)isDismiss {
    _isDismiss = isDismiss;
    if (self.delegate && [self.delegate respondsToSelector:@selector(isDragForDown:)]) {
        [self.delegate isDragForDown:isDismiss];
    }
}
- (void)setImageUrlString:(NSString *)imageUrlString {
    _imageUrlString = imageUrlString;
    
    [self.pictureImageView sd_setImageWithURL:[NSURL URLWithString:imageUrlString] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
        if (image) {
            CGFloat height = image.size.height / image.size.width * SCREEN_W;
//            if (height>=SCREEN_H) {
//                height = SCREEN_H;
//            }
            self.pictureImageView.bounds = CGRectMake(0, 0, SCREEN_W, height);
            self.pictureScrollView.contentSize = self.pictureImageView.bounds.size;
            self.pictureImageView.center = [self centerOfScrollViewContent:self.pictureScrollView];
        }else {
//            self.pictureImageView.image = [TTUtils makePlaceholderImageWithSize:self.pictureImageView.bounds.size];
        }
    }];
}
#pragma mark - 懒加载
- (UIScrollView *)pictureScrollView {
    if (!_pictureScrollView) {
        _pictureScrollView = [UIScrollView new];
        _pictureScrollView.delegate = self;
        _pictureScrollView.maximumZoomScale = 2.0;//最大放大倍数
        _pictureScrollView.minimumZoomScale = 1.0;//最小缩小倍数
        _pictureScrollView.scrollsToTop = NO;
        _pictureScrollView.showsVerticalScrollIndicator = NO;
        _pictureScrollView.showsHorizontalScrollIndicator = NO;
        _pictureScrollView.alwaysBounceVertical = YES;
        _pictureScrollView.zoomScale = 1.0f;//当前缩放比例
        _pictureScrollView.contentOffset = CGPointZero;//当前偏移
//        _pictureScrollView.alwaysBounceHorizontal = YES;
        _pictureScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        [_pictureScrollView.panGestureRecognizer addTarget:self action:@selector(panGestureRecognizerAction:)];
    }
    return _pictureScrollView;
}
- (UIImageView *)pictureImageView {
    if (!_pictureImageView) {
        _pictureImageView = [UIImageView new];
        _pictureImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _pictureImageView;
}
@end
