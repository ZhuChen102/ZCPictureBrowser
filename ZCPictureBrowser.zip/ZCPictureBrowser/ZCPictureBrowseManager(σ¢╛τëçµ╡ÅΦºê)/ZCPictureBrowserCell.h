//
//  ZCPictureBrowserCell.h
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ZCPictureBrowserCellDelegate <NSObject>

@optional
- (void)isDragForDown:(BOOL)isDown;
- (void)isNeedBack:(UIImageView *)toImageView;
- (void)refreshAlpha:(CGFloat)alpha;
@end

@interface ZCPictureBrowserCell : UICollectionViewCell

@property (nonatomic, copy) NSString *imageUrlString;

@property (nonatomic, weak) id<ZCPictureBrowserCellDelegate>delegate;

- (void)resetScale;

@end

NS_ASSUME_NONNULL_END
