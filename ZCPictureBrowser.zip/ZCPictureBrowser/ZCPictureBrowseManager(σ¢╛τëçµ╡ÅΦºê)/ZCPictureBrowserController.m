//
//  ZCPictureBrowserController.m
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import "ZCPictureBrowserController.h"
#import "ZCPictureBrowserCell.h"
#import "ZCPictureBrowserTranslation.h"

#define Margin_Black 5.0

@interface ZCPictureBrowserController () <UICollectionViewDelegate, UICollectionViewDataSource, ZCPictureBrowserCellDelegate, UIViewControllerTransitioningDelegate>
@property (nonatomic, strong) UICollectionView *picCollectionView;
@property (nonatomic, strong) ZCPictureBrowserTranslation *translation;
//改变背景的透明度
@property (nonatomic, assign) CGFloat vcAlpha;
@end

@implementation ZCPictureBrowserController

- (instancetype)init {
    if (self = [super init]) {
        self.modalPresentationStyle = UIModalPresentationOverCurrentContext;
        self.transitioningDelegate = self;//转场管理者
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initData];
    [self initUI];
}
- (void)initData {
    self.translation.fromView = self.fromView;
    self.translation.beginIndex = self.selectedIndex;
    self.vcAlpha = 1.0;
}
- (void)initUI {
    self.view.backgroundColor = UIColor.blackColor;
    [self.view addSubview:self.picCollectionView];
    
    [self.picCollectionView setContentOffset:CGPointMake(self.selectedIndex*([UIScreen mainScreen].bounds.size.width+2*Margin_Black), 0) animated:NO];
}

#pragma mark - 代理
#pragma mark -- UIViewControllerTransitioningDelegate(转场动画代理)
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    self.translation.transitionType = TransitionTypePresent;
    return self.translation;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    self.translation.transitionType = TransitionTypeDissmiss;
    return self.translation;
}
#pragma mark — UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.imageArray.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ZCPictureBrowserCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ZCPictureBrowseCell" forIndexPath:indexPath];
    cell.imageUrlString = self.imageArray[indexPath.row];
    cell.delegate = self;
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    ZCPictureBrowserCell *picCell = (ZCPictureBrowserCell *)cell;
    [picCell resetScale];
}
#pragma mark -- ZCPictureBrowserCellDelegate
- (void)isDragForDown:(BOOL)isDown {
    self.picCollectionView.scrollEnabled = !isDown;
}
- (void)refreshAlpha:(CGFloat)alpha {
    self.vcAlpha = alpha;
    self.view.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:alpha];
}
- (void)isNeedBack:(UIImageView *)toImageView {
    NSInteger dismissIndex = [self.picCollectionView indexPathsForVisibleItems].firstObject.row;
    self.translation.toImageView = toImageView;
    self.translation.toImageViewAlpha = self.vcAlpha;
    self.translation.finalIndex = dismissIndex;
    
    if (self.completeBlock) {
        self.completeBlock(dismissIndex);
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 懒加载
- (UICollectionView *)picCollectionView {
    if (!_picCollectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        flowLayout.itemSize = [UIScreen mainScreen].bounds.size;
        flowLayout.minimumLineSpacing = 2*Margin_Black; //水平间距
        flowLayout.sectionInset = UIEdgeInsetsMake(0, Margin_Black, 0, Margin_Black);
        
        _picCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(-Margin_Black, 0, [UIScreen mainScreen].bounds.size.width+2*Margin_Black, [UIScreen mainScreen].bounds.size.height) collectionViewLayout:flowLayout];
        _picCollectionView.showsHorizontalScrollIndicator = NO;
        _picCollectionView.backgroundColor = UIColor.clearColor;
        _picCollectionView.pagingEnabled = YES;
        _picCollectionView.delegate = self;
        _picCollectionView.dataSource = self;
        [_picCollectionView registerClass:[ZCPictureBrowserCell class] forCellWithReuseIdentifier:@"ZCPictureBrowseCell"];
    }
    return _picCollectionView;
}

- (ZCPictureBrowserTranslation *)translation {
    if (!_translation) {
        _translation = [ZCPictureBrowserTranslation new];
    }
    return _translation;
}
@end
