//
//  ZCPictureBrowserController.h
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/12.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

typedef void (^CompleteBlock)(NSInteger index);

@interface ZCPictureBrowserController : UIViewController

@property (nonatomic, copy) NSArray *imageArray;
@property (nonatomic, assign) NSInteger selectedIndex;
@property (nonatomic, strong) UIView *fromView;
@property (nonatomic, copy) CompleteBlock completeBlock;
@end

NS_ASSUME_NONNULL_END
