//
//  ZCPictureBrowserTranslation.m
//  ZCPictureBrowser
//
//  Created by Chen.zhu on 2020/8/13.
//  Copyright © 2020 Chen.zhu. All rights reserved.
//

#import "ZCPictureBrowserTranslation.h"
#import "ZCPictureBrowserController.h"

#define DurationTime 0.25
#define SCREEN_W ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_H ([UIScreen mainScreen].bounds.size.height)

@interface ZCPictureBrowserTranslation ()

@end


@implementation ZCPictureBrowserTranslation
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return DurationTime;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    switch (self.transitionType) {
        case TransitionTypePresent: {
            [self presentAnimation:transitionContext];
        }break;
        case TransitionTypeDissmiss: {
            [self dismissAnimation:transitionContext];
        }break;
    }
}

- (void)presentAnimation:(id<UIViewControllerContextTransitioning>)transitionContext {
    //转场的来源控制器
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    //转场去往的控制器
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];

    //转场过程中显示的view，所有动画控件都应该加在这上面
    UIView *containerView = [transitionContext containerView];
    
    //添加背景
    UIView *bgView = [UIView new];
    bgView.frame = containerView.frame;
    bgView.backgroundColor = UIColor.blackColor;
    bgView.alpha = 0;
    [containerView addSubview:bgView];
    
    // 动画开始视图
    UIImageView *fromImageView = [[UIImageView alloc]init];
    fromImageView.contentMode = UIViewContentModeScaleAspectFill;
    fromImageView.clipsToBounds = YES;
    [containerView addSubview:fromImageView];

    // 动画结束
    [containerView addSubview:toVC.view];
    
    if (self.fromView) {
        //fromView 的 Frame 要转换为控制器view的
        fromImageView.frame = [self getFrameWithFromCollectionView:self.fromView andIndex:self.beginIndex];
        fromImageView.image = [self getImageWithFromCollectionView:self.fromView andIndex:self.beginIndex];
        
        CGFloat height = fromImageView.image.size.height / fromImageView.image.size.width * SCREEN_W;
        CGRect toFrame = CGRectMake(0, 0, SCREEN_W, height);
        if (height<=[UIScreen mainScreen].bounds.size.height) {
            toFrame = CGRectMake(0, (SCREEN_H-height)/2.0, SCREEN_W, height);
        }
        
        toVC.view.hidden = YES;
        [UIView animateWithDuration:DurationTime animations:^{
            [containerView layoutIfNeeded];
            bgView.alpha = 1.0;
            fromImageView.frame = toFrame;
        }completion:^(BOOL finished) {
            toVC.view.hidden = NO;
            [bgView removeFromSuperview];
            [fromImageView removeFromSuperview];
            [transitionContext completeTransition:YES];
        }];
    } else {
        
        fromImageView.frame = [self getFrameWithFromCollectionView:fromVC.view andIndex:self.beginIndex];
        fromImageView.image = [self getImageWithFromCollectionView:fromVC.view andIndex:self.beginIndex];
        
        [UIView animateWithDuration:DurationTime animations:^{
            [containerView layoutIfNeeded];
            bgView.alpha = 1.0;
            fromImageView.alpha = 0;
        }completion:^(BOOL finished) {
            [bgView removeFromSuperview];
            [fromImageView removeFromSuperview];
            [transitionContext completeTransition:YES];
        }];
                
    }
}

- (void)dismissAnimation:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    //转场的来源控制器
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    fromVC.view.hidden = YES;

    //转场过程中显示的view，所有动画控件都应该加在这上面
    UIView *containerView = [transitionContext containerView];
    
    //添加背景
    UIView *bgView = [UIView new];
    bgView.frame = containerView.frame;
    bgView.backgroundColor = UIColor.blackColor;
    [containerView addSubview:bgView];
    
    //
    UIImageView *toView = [[UIImageView alloc]init];
    toView.contentMode = UIViewContentModeScaleAspectFill;
    toView.clipsToBounds = YES;
    [containerView addSubview:toView];
        
    toView.frame = self.toImageView.frame;
    toView.image = self.toImageView.image;
    bgView.alpha = self.toImageViewAlpha;
    
    if (self.fromView) {
        CGRect fromFrame = [self getFrameWithFromCollectionView:self.fromView andIndex:self.finalIndex];
        if (fromFrame.origin.x >= SCREEN_W || fromFrame.origin.x+fromFrame.size.width <= 0 || fromFrame.origin.y >= SCREEN_H || fromFrame.origin.y+fromFrame.size.height <= 0) { //不在视图内 直接淡化动画
            [UIView animateWithDuration:DurationTime animations:^{
                [containerView layoutIfNeeded];
                bgView.alpha = 0;
                toView.alpha = 0;
            }completion:^(BOOL finished) {
                [bgView removeFromSuperview];
                [toView removeFromSuperview];
                [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
            }];
        } else { //在可视视图内 则做动画
            [UIView animateWithDuration:DurationTime animations:^{
                [containerView layoutIfNeeded];
                bgView.alpha = 0;
                toView.frame = fromFrame;
            }completion:^(BOOL finished) {
                [bgView removeFromSuperview];
                [toView removeFromSuperview];
                [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
            }];
        }
    } else { //淡化处理
        [UIView animateWithDuration:DurationTime animations:^{
            [containerView layoutIfNeeded];
            bgView.alpha = 0;
            toView.alpha = 0;
        }completion:^(BOOL finished) {
            [bgView removeFromSuperview];
            [toView removeFromSuperview];
            [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
        }];
    }
}

#pragma mark # 获取想要的位置
- (CGRect)getFrameWithFromCollectionView:(UIView *)view andIndex:(NSInteger)index {
    
    if ([NSStringFromClass([view class]) isEqualToString:@"UICollectionView"]) {
        
        UICollectionView *collectionView = (UICollectionView *)view;
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
        CGRect rect = [cell.contentView convertRect:cell.contentView.frame toView:[UIApplication sharedApplication].keyWindow];
        return rect;
        
    } else {
        
        CGRect rect = [view convertRect:view.frame toView:[UIApplication sharedApplication].keyWindow];
        return rect;
        
    }
}
- (UIImage *)getImageWithFromCollectionView:(UIView *)view andIndex:(NSInteger)index {
    
    if ([NSStringFromClass([view class]) isEqualToString:@"UICollectionView"]) {
        
        UICollectionView *collectionView = (UICollectionView *)view;
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
        UIImageView *imageView;
        for (UIView *subV in cell.contentView.subviews) {
            if ([NSStringFromClass([subV class]) isEqualToString:@"UIImageView"]) {
                imageView = (UIImageView *)subV;
            }
        }
        UIImage *image;
        if (imageView) {
            image = imageView.image;
        }else {
//            image = [TTUtils makePlaceholderImageWithSize:cell.contentView.bounds.size];
        }
        return image;
        
    } else if ([NSStringFromClass([view class]) isEqualToString:@"UIImageView"]) {
        UIImageView *imageView = (UIImageView *)view;
        UIImage *image = imageView.image;
        
        if (!image) {
//            image = [TTUtils makePlaceholderImageWithSize:imageView.bounds.size];
        }

        return image;
        
    } else {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, YES, [UIScreen mainScreen].scale);
        [view.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return image;
    }
}
@end
